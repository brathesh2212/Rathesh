import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, Link, useLocation, useRoute, Router as WouterRouter } from 'wouter';
import {
  ArrowDownRight, ArrowLeft, ArrowRight, Atom, Bookmark, BookOpen, BookMarked, Check, ChevronDown, ChevronRight, CircleHelp,
  Clock3, Code2, FileQuestion, FileText, FlaskConical, GraduationCap, Grid2X2, Heart, Home, Info, LayoutDashboard, Library,
  Menu, MessageCircle, Moon, MoreHorizontal, Pencil, Plus, Search, Send, Settings2, Sparkles, Sun, Upload, UserRound, X,
  Trash2, Download, ExternalLink, PanelLeftClose, BookmarkCheck, NotebookPen, RotateCcw, Star, ScrollText, Activity,
} from 'lucide-react';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const navItems = [
  { path: '/', label: 'Overview', icon: LayoutDashboard },
  { path: '/subjects', label: 'Subjects', icon: Library },
  { path: '/notes', label: 'My notes', icon: NotebookPen },
  { path: '/important-questions', label: 'Exam questions', icon: FileQuestion },
  { path: '/pdfs', label: 'PDF shelf', icon: FileText },
  { path: '/ai', label: 'Ask StudyMate', icon: MessageCircle },
  { path: '/bookmarks', label: 'Bookmarks', icon: Bookmark },
  { path: '/profile', label: 'My profile', icon: UserRound },
  { path: '/about', label: 'About', icon: Info },
];
const subjects = [
  { id: 'math', title: 'Mathematics', units: 5, notes: 12, icon: Grid2X2, color: 'mint', focus: 'Calculus · Linear algebra' },
  { id: 'physics', title: 'Physics', units: 4, notes: 9, icon: Atom, color: 'sky', focus: 'Mechanics · Waves' },
  { id: 'chemistry', title: 'Chemistry', units: 5, notes: 11, icon: FlaskConical, color: 'peach', focus: 'Atomic structure · Bonds' },
  { id: 'c', title: 'Programming in C', units: 6, notes: 14, icon: Code2, color: 'yellow', focus: 'Pointers · Data structures' },
  { id: 'english', title: 'English', units: 3, notes: 6, icon: BookOpen, color: 'lavender', focus: 'Communication · Writing' },
  { id: 'graphics', title: 'Engineering Graphics', units: 5, notes: 8, icon: Pencil, color: 'rose', focus: 'Projection · Isometric views' },
];
type StudyNote = { id: string; subject: string; unit: string; title: string; summary: string; updated: string; type: 'Note' | 'Topic' };
const starterNotes: StudyNote[] = [
  { id: 'n1', subject: 'Mathematics', unit: 'Unit 2 · Differential calculus', title: 'Limits and continuity', summary: 'A compact recap of limit laws, continuity at a point, and the standard indeterminate forms.', updated: 'Today', type: 'Note' },
  { id: 'n2', subject: 'Mathematics', unit: 'Unit 3 · Integral calculus', title: 'Integration by parts', summary: 'Choosing u and dv with the LIATE rule, plus a few common forms worth remembering.', updated: 'Yesterday', type: 'Topic' },
  { id: 'n3', subject: 'Physics', unit: 'Unit 1 · Mechanics', title: 'Work, energy & power', summary: 'Conservative forces, work-energy theorem, and quick dimensional checks.', updated: '2 days ago', type: 'Note' },
  { id: 'n4', subject: 'Programming in C', unit: 'Unit 4 · Pointers', title: 'Pointer arithmetic', summary: 'How pointer increments scale by the size of the pointed-to type.', updated: 'Mon', type: 'Topic' },
  { id: 'n5', subject: 'Chemistry', unit: 'Unit 2 · Chemical bonding', title: 'Hybridisation quick guide', summary: 'A shape-first way to connect steric number, hybrid orbitals and molecular geometry.', updated: 'May 18', type: 'Note' },
  { id: 'n6', subject: 'Engineering Graphics', unit: 'Unit 3 · Projections', title: 'Orthographic projection', summary: 'First-angle convention and a checklist for front, top and side views.', updated: 'May 16', type: 'Topic' },
  { id: 'n7', subject: 'English', unit: 'Unit 1 · Communication', title: 'Formal email structure', summary: 'Subject lines, clear asks and a courteous close for professional correspondence.', updated: 'May 14', type: 'Note' },
];
type ExamQuestion = { id: string; subject: string; unit: string; text: string; marks: number; kind: string };
const questions: ExamQuestion[] = [
  { id: 'q1', subject: 'Mathematics', unit: 'Unit 2 · Differential calculus', text: 'State and prove the chain rule for differentiation. Illustrate with a suitable example.', marks: 8, kind: 'Long answer' },
  { id: 'q2', subject: 'Mathematics', unit: 'Unit 3 · Integral calculus', text: 'Evaluate the integral using integration by parts and explain your choice of u.', marks: 6, kind: 'Problem' },
  { id: 'q3', subject: 'Physics', unit: 'Unit 1 · Mechanics', text: 'Derive the work-energy theorem for a particle moving under a constant force.', marks: 8, kind: 'Derivation' },
  { id: 'q4', subject: 'Programming in C', unit: 'Unit 4 · Pointers', text: 'Explain the relationship between arrays and pointers with a short C program.', marks: 10, kind: 'Program' },
  { id: 'q5', subject: 'Chemistry', unit: 'Unit 2 · Chemical bonding', text: 'Predict the molecular shape of NH₃ using VSEPR theory. Explain the bond angle.', marks: 5, kind: 'Short answer' },
  { id: 'q6', subject: 'Engineering Graphics', unit: 'Unit 3 · Projections', text: 'Draw the orthographic views of a point positioned above HP and in front of VP.', marks: 6, kind: 'Drawing' },
  { id: 'q7', subject: 'English', unit: 'Unit 1 · Communication', text: 'Write a formal email requesting an appointment with your department coordinator.', marks: 5, kind: 'Writing' },
];
type SavedPdf = { id: string; name: string; size: string; url: string; added: string };
type ChatLine = { role: 'user' | 'assistant'; text: string };
const getSaved = <T,>(key: string, fallback: T): T => { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) as T : fallback; } catch { return fallback; } };
const recordActivity = (label: string) => {
  const entries = getSaved<string[]>('sm-activity', []);
  localStorage.setItem('sm-activity', JSON.stringify([`${label} · just now`, ...entries.filter(x => !x.includes(label))].slice(0, 5)));
};
const demoAnswer = (question: string) => `Let's make this manageable. Start by identifying the key idea in “${question.slice(0, 58)}${question.length > 58 ? '…' : ''}”.\n\nBreak it into three steps: write down what is given, connect it to the relevant definition or formula, then work through one line at a time. Check your units or assumptions at the end.\n\nThis is a demo response for your study session, not a live AI answer. Add your lecture context and I can help you shape a more focused explanation.`;

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><RoutedErrorBoundary><StudyMate /></RoutedErrorBoundary></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function StudyMate() {
  const [location, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [dark, setDark] = useState(() => getSaved('sm-theme', false));
  const [bookmarks, setBookmarks] = useState<string[]>(() => getSaved('sm-bookmarks', ['n1', 'q1']));
  const [notes, setNotes] = useState<StudyNote[]>(() => getSaved('sm-notes', starterNotes));
  const [recentNoteIds, setRecentNoteIds] = useState<string[]>(() => getSaved('sm-recent-notes', ['n1', 'n3', 'n4']));
  const [profile, setProfile] = useState(() => getSaved('sm-profile', { name: 'Rathesh B', course: 'Engineering student', year: 'Year 1', email: 'rathesh.b@student.edu', dailyGoal: '45 minutes' }));
  const [activity, setActivity] = useState<string[]>(() => getSaved('sm-activity', ['Opened Mathematics notes · yesterday', 'Saved a calculus question · yesterday', 'Visited your PDF shelf · 2 days ago']));
  const [pdfs, setPdfs] = useState<SavedPdf[]>([]);
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); localStorage.setItem('sm-theme', JSON.stringify(dark)); }, [dark]);
  useEffect(() => { localStorage.setItem('sm-bookmarks', JSON.stringify(bookmarks)); }, [bookmarks]);
  useEffect(() => { localStorage.setItem('sm-notes', JSON.stringify(notes)); }, [notes]);
  useEffect(() => { localStorage.setItem('sm-recent-notes', JSON.stringify(recentNoteIds)); }, [recentNoteIds]);
  useEffect(() => { localStorage.setItem('sm-profile', JSON.stringify(profile)); }, [profile]);
  useEffect(() => { localStorage.setItem('sm-activity', JSON.stringify(activity)); }, [activity]);
  useEffect(() => { document.title = `${navItems.find(i => i.path === location)?.label ?? 'StudyMate'} · StudyMate`; }, [location]);
  const visit = (label: string) => { const next = [`${label} · just now`, ...activity.filter(x => !x.includes(label))].slice(0, 5); setActivity(next); };
  const markNoteViewed = (id: string) => {
    const note = notes.find(item => item.id === id);
    if (!note) return;
    setRecentNoteIds(prev => [id, ...prev.filter(previousId => previousId !== id)].slice(0, 5));
    visit(`Opened ${note.title}`);
  };
  const flipBookmark = (id: string) => setBookmarks(prev => prev.includes(id) ? prev.filter(x => x !== id) : [id, ...prev]);
  const openNav = (path: string, label: string) => { setLocation(path); visit(label); setMenuOpen(false); };
  const content = (path: string) => <Switch>
    <Route path="/" component={() => <HomePage notes={notes} bookmarks={bookmarks} visit={visit} recentNoteIds={recentNoteIds} onViewNote={markNoteViewed} />} />
    <Route path="/subjects" component={() => <SubjectsPage onOpen={() => openNav('/notes', 'Opened subject notes')} />} />
    <Route path="/notes" component={() => <NotesPage notes={notes} setNotes={setNotes} bookmarks={bookmarks} onBookmark={flipBookmark} onView={markNoteViewed} />} />
    <Route path="/important-questions" component={() => <QuestionsPage bookmarks={bookmarks} onBookmark={flipBookmark} />} />
    <Route path="/pdfs" component={() => <PdfsPage pdfs={pdfs} setPdfs={setPdfs} />} />
    <Route path="/ai" component={() => <AiPage />} />
    <Route path="/bookmarks" component={() => <BookmarksPage notes={notes} bookmarks={bookmarks} onBookmark={flipBookmark} />} />
    <Route path="/profile" component={() => <ProfilePage profile={profile} setProfile={setProfile} activity={activity} onClearActivity={() => setActivity([])} dark={dark} setDark={setDark} />} />
    <Route path="/about" component={AboutPage} />
    <Route component={NotFound} />
  </Switch>;
  return <div className="app-frame flex">
    {menuOpen && <button className="fixed inset-0 z-30 bg-black/35 md:hidden" aria-label="Close navigation overlay" onClick={() => setMenuOpen(false)} data-testid="button-close-overlay" />}
    <aside className={`side-nav fixed inset-y-0 left-0 z-40 flex w-[256px] flex-col px-4 py-5 transition-transform duration-300 md:sticky md:top-0 md:h-dvh md:translate-x-0 ${menuOpen ? 'translate-x-0' : '-translate-x-full'}`} aria-label="Main navigation">
      <Link href="/" className="mb-9 flex items-center gap-3 px-2" data-testid="link-brand">
        <span className="grid h-10 w-10 place-items-center rounded-[14px] bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]"><GraduationCap size={23} strokeWidth={2.2} /></span>
        <span><span className="display-font block text-[18px] font-extrabold tracking-[-.04em]">StudyMate</span><span className="block text-[10px] uppercase tracking-[.19em] opacity-60">your study space</span></span>
      </Link>
      <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[.2em] opacity-45">Workspace</div>
      <nav className="space-y-1" aria-label="StudyMate sections">{navItems.map(item => {
        const Icon = item.icon; const active = location === item.path;
        return <Link key={item.path} href={item.path} onClick={() => openNav(item.path, item.label)} className={`group flex items-center gap-3 rounded-xl px-3 py-[10px] text-[13px] font-medium ${active ? 'bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-primary))]' : 'opacity-75 hover:bg-white/5 hover:opacity-100'}`} aria-current={active ? 'page' : undefined} data-testid={`link-nav-${item.path.slice(1) || 'home'}`}>
          <Icon size={17} strokeWidth={active ? 2.3 : 1.8} /><span className="flex-1">{item.label}</span>{item.path === '/bookmarks' && bookmarks.length > 0 && <span className="rounded-full bg-white/10 px-1.5 py-0.5 text-[10px]">{bookmarks.length}</span>}
        </Link>;
      })}</nav>
      <div className="mt-auto rounded-2xl border border-white/10 bg-white/[.04] p-4">
        <div className="mb-2 flex items-center justify-between text-[11px] opacity-60"><span>STUDY RHYTHM</span><span>01</span></div>
        <div className="display-font text-[16px] font-bold leading-snug">Little by little,<br />a lot gets done.</div>
        <div className="mt-4 h-1.5 rounded-full bg-white/10"><div className="h-full w-[62%] rounded-full bg-[hsl(var(--sidebar-primary))]" /></div>
        <div className="mt-2 text-[10px] opacity-50">Your space, your pace.</div>
      </div>
      <div className="mt-4 flex items-center gap-3 rounded-xl px-2 py-2">
        <div className="grid h-9 w-9 place-items-center rounded-full bg-[hsl(var(--sidebar-primary))] font-bold text-[hsl(var(--sidebar-primary-foreground))]">RB</div>
        <div className="min-w-0 flex-1"><div className="truncate text-[12px] font-semibold">Rathesh B</div><div className="text-[10px] opacity-55">My study space</div></div>
        <button type="button" aria-label={dark ? 'Switch to light theme' : 'Switch to dark theme'} onClick={() => setDark(!dark)} className="rounded-lg p-2 opacity-65 hover:bg-white/10 hover:opacity-100" data-testid="button-theme-toggle">{dark ? <Sun size={16} /> : <Moon size={16} />}</button>
      </div>
    </aside>
    <div className="min-w-0 flex-1">
      <header className="sticky top-0 z-20 flex h-[68px] items-center justify-between border-b border-border/70 bg-background/90 px-4 backdrop-blur-md sm:px-7 lg:px-10">
        <div className="flex items-center gap-3">
          <button type="button" className="rounded-xl border border-border bg-card p-2 md:hidden" aria-label="Open navigation" onClick={() => setMenuOpen(true)} data-testid="button-open-menu"><Menu size={19} /></button>
          <div className="hidden items-center gap-2 text-[12px] text-muted-foreground sm:flex"><span>StudyMate</span><ChevronRight size={14} /><span className="font-semibold text-foreground">{navItems.find(i => i.path === location)?.label || 'Page'}</span></div>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden text-right sm:block"><div className="text-[12px] font-semibold">A good day to learn</div><div className="text-[10px] text-muted-foreground">Keep your momentum gentle.</div></div>
          <div className="grid h-9 w-9 place-items-center rounded-full border border-border bg-card text-[12px] font-bold text-primary">RB</div>
        </div>
      </header>
      <main key={location} className="page-enter mx-auto max-w-[1320px] px-4 pb-12 pt-7 sm:px-7 lg:px-10 lg:pt-10">{content(location)}</main>
      <footer className="mx-auto max-w-[1320px] px-4 pb-8 text-center text-[11px] text-muted-foreground sm:px-7 lg:px-10">Founded by Rathesh B <span className="px-1.5">·</span> A little more clarity, every study session.</footer>
    </div>
  </div>;
}

function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><div className="mb-2 text-[10px] font-bold uppercase tracking-[.2em] text-primary">{eyebrow}</div><h1 className="display-font text-[32px] font-extrabold leading-[1.08] tracking-[-.045em] sm:text-[40px]" data-testid="text-page-title">{title}</h1><p className="mt-2 max-w-2xl text-[13px] leading-6 text-muted-foreground">{subtitle}</p></div>{action}</div>;
}
function Button({ children, onClick, variant = 'primary', testId, type = 'button', disabled = false }: { children: ReactNode; onClick?: () => void; variant?: 'primary' | 'outline' | 'soft' | 'danger'; testId: string; type?: 'button' | 'submit'; disabled?: boolean }) {
  const cls = variant === 'primary' ? 'bg-primary text-primary-foreground hover:opacity-90' : variant === 'outline' ? 'border border-border bg-card hover:border-primary/40 hover:bg-muted' : variant === 'danger' ? 'bg-destructive/10 text-destructive hover:bg-destructive/15' : 'bg-secondary text-secondary-foreground hover:opacity-85';
  return <button type={type} disabled={disabled} onClick={onClick} data-testid={testId} className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-[12px] font-semibold disabled:cursor-not-allowed disabled:opacity-50 ${cls}`}>{children}</button>;
}
function EmptyState({ icon: Icon, title, text, action }: { icon: typeof BookOpen; title: string; text: string; action?: ReactNode }) {
  return <div className="flex min-h-[260px] flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card/50 px-5 text-center"><span className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-primary"><Icon size={22} /></span><h3 className="display-font text-[17px] font-bold">{title}</h3><p className="mt-1 max-w-sm text-[12px] leading-5 text-muted-foreground">{text}</p>{action && <div className="mt-4">{action}</div>}</div>;
}
function HomePage({ notes, bookmarks, visit, recentNoteIds, onViewNote }: { notes: StudyNote[]; bookmarks: string[]; visit: (label: string) => void; recentNoteIds: string[]; onViewNote: (id: string) => void }) {
  const [quickSearch, setQuickSearch] = useState('');
  const [location, setLocation] = useLocation();
  const searchResults = useMemo(() => {
    const term = quickSearch.trim().toLowerCase();
    if (!term) return [];
    const noteResults = notes
      .filter(n => `${n.title} ${n.subject} ${n.unit} ${n.summary}`.toLowerCase().includes(term))
      .slice(0, 2)
      .map(n => ({ id: n.id, title: n.title, detail: n.subject, kind: 'Note', path: '/notes' }));
    const subjectResults = subjects
      .filter(s => `${s.title} ${s.focus}`.toLowerCase().includes(term))
      .slice(0, 2)
      .map(s => ({ id: s.id, title: s.title, detail: s.focus, kind: 'Subject', path: '/subjects' }));
    const questionResults = questions
      .filter(q => `${q.text} ${q.subject} ${q.unit}`.toLowerCase().includes(term))
      .slice(0, 2)
      .map(q => ({ id: q.id, title: q.text, detail: q.subject, kind: 'Question', path: '/important-questions' }));
    return [...noteResults, ...subjectResults, ...questionResults];
  }, [notes, quickSearch]);
  const shortcuts = [
    { path: '/notes', id: 'notes', label: 'Notes', caption: 'Class notes & topics', icon: NotebookPen },
    { path: '/important-questions', id: 'questions', label: 'Important questions', caption: 'Practice for exams', icon: FileQuestion },
    { path: '/pdfs', id: 'pdfs', label: 'PDFs', caption: 'Handouts & reading', icon: FileText },
    { path: '/bookmarks', id: 'bookmarks', label: 'Bookmarks', caption: 'Your saved materials', icon: Bookmark },
  ];
  const recentlyViewedNotes = recentNoteIds
    .map(id => notes.find(note => note.id === id))
    .filter((note): note is StudyNote => Boolean(note))
    .slice(0, 3);
  return <div>
    <section className="relative mb-7 overflow-hidden rounded-[26px] bg-primary px-6 py-8 text-primary-foreground sm:px-10 sm:py-10">
      <div className="paper-grid absolute inset-0 opacity-40" /><div className="absolute -right-12 -top-20 h-64 w-64 rounded-full border border-white/10" /><div className="absolute -right-2 top-6 h-40 w-40 rounded-full border border-white/10" />
      <div className="relative max-w-2xl">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[.06] px-3 py-1.5 text-[10px] font-semibold tracking-wide text-primary-foreground/80"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--sidebar-primary))]" />YOUR PERSONAL STUDY DESK</div>
        <h1 className="display-font text-[32px] font-extrabold leading-tight tracking-[-.05em] sm:text-[46px]" data-testid="text-greeting">Hey Rathesh 👋</h1>
        <p className="mt-3 max-w-lg text-[13px] leading-6 text-primary-foreground/70">A clearer head starts here. Pick up where you left off, or find a fresh thread to follow.</p>
        <div className="relative mt-6 max-w-[490px]">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-primary-foreground/50" size={17} />
          <input aria-label="Search notes, subjects, and questions" data-testid="input-dashboard-search" value={quickSearch} onChange={e => setQuickSearch(e.target.value)} placeholder="Search notes, subjects, questions..." className="w-full rounded-xl border border-white/15 bg-white/10 py-3 pl-11 pr-4 text-[12px] text-white outline-none placeholder:text-white/45 focus:border-white/40" />
          {quickSearch && <div className="absolute left-0 right-0 top-[calc(100%+8px)] z-10 rounded-xl border border-border bg-card p-2 text-foreground soft-shadow">{searchResults.length ? searchResults.map(result => <button key={`${result.kind}-${result.id}`} onClick={() => { if (result.kind === 'Note') onViewNote(result.id); setLocation(`${result.path}?search=${encodeURIComponent(quickSearch.trim())}`); visit(`Searched ${result.kind.toLowerCase()}`); }} className="flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-left hover:bg-muted" data-testid={`button-search-result-${result.kind.toLowerCase()}-${result.id}`}><span className="min-w-0 truncate text-[12px] font-semibold">{result.title}</span><span className="shrink-0 text-[10px] text-muted-foreground">{result.kind} · {result.detail}</span></button>) : <div className="p-3 text-[12px] text-muted-foreground">No matching notes, subjects, or questions yet.</div>}</div>}
        </div>
      </div>
      <div className="relative mt-7 flex flex-wrap gap-2"><Link href="/subjects" className="inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--sidebar-primary))] px-4 py-2.5 text-[12px] font-bold text-[hsl(var(--sidebar-primary-foreground))] hover:brightness-95" data-testid="link-browse-subjects">Browse subjects <ArrowRight size={15} /></Link><Link href="/ai" className="inline-flex items-center gap-2 rounded-xl border border-white/20 px-4 py-2.5 text-[12px] font-semibold text-white hover:bg-white/10" data-testid="link-ask-hero"><Sparkles size={15} /> Ask a question</Link></div>
      <div className="absolute bottom-9 right-12 hidden rotate-[-8deg] rounded-2xl border border-white/15 bg-white/[.08] p-4 text-[10px] leading-5 text-white/75 lg:block"><span className="font-mono text-[9px] tracking-widest opacity-60">NOTE TO SELF</span><br />Progress, not perfection.<br /><span className="mt-1 inline-block border-t border-white/20 pt-1 opacity-50">keep going →</span></div>
    </section>
    <section className="mb-8" aria-label="Quick access">
      <div className="mb-3 text-[10px] font-bold uppercase tracking-[.18em] text-primary">QUICK ACCESS</div>
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        {shortcuts.map(({ path, id, label, caption, icon: Icon }) => <Link key={id} href={path} className="lift-card flex min-h-[88px] items-center gap-3 rounded-2xl border border-border bg-card p-3.5 sm:p-4" data-testid={`link-quick-${id}`}>
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-secondary text-primary"><Icon size={18} /></span>
          <span className="min-w-0 flex-1"><span className="block truncate text-[11px] font-bold sm:text-[12px]">{label}</span><span className="mt-1 block truncate text-[9px] text-muted-foreground">{caption}</span></span>
          <ArrowRight size={13} className="shrink-0 text-muted-foreground" />
        </Link>)}
      </div>
    </section>
    <div className="mb-8 grid gap-4 md:grid-cols-[1.55fr_1fr]">
      <Link href="/ai" className="group relative flex min-h-[160px] items-center justify-between overflow-hidden rounded-2xl border border-border bg-card p-5 soft-shadow sm:p-7" data-testid="link-featured-ai">
        <div className="relative z-[1] max-w-md"><div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.19em] text-primary"><Sparkles size={14} /> STUDY SUPPORT</div><h2 className="display-font text-[24px] font-extrabold tracking-[-.04em] sm:text-[30px]">Ask StudyMate AI 🤖</h2><p className="mt-1 text-[12px] text-muted-foreground">Untangle a concept. Get a demo explanation, step by step.</p><div className="mt-4 inline-flex items-center gap-2 text-[11px] font-bold text-primary">Start a question <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" /></div></div>
        <div className="absolute -right-6 -top-8 h-44 w-44 rounded-full bg-secondary/70" /><div className="relative mr-2 hidden h-[90px] w-[90px] rotate-3 items-center justify-center rounded-[28px] bg-secondary text-primary sm:flex"><MessageCircle size={37} strokeWidth={1.4} /><span className="absolute -right-1 -top-1 grid h-7 w-7 place-items-center rounded-full bg-accent text-accent-foreground"><Sparkles size={14} /></span></div>
      </Link>
      <div className="flex items-center gap-4 rounded-2xl border border-border bg-[hsl(var(--accent))] p-5 sm:p-7"><div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-card text-accent-foreground"><BookMarked size={22} /></div><div><div className="text-[10px] font-bold uppercase tracking-[.16em] text-accent-foreground/65">ON YOUR SHORTLIST</div><div className="display-font mt-1 text-[25px] font-extrabold leading-none">{bookmarks.length}<span className="ml-2 text-[13px] font-semibold">saved items</span></div><Link href="/bookmarks" className="mt-2 inline-block text-[11px] font-semibold underline decoration-accent-foreground/30 underline-offset-4" data-testid="link-view-bookmarks">Go to bookmarks</Link></div></div>
    </div>
    <div className="mb-5 flex items-end justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[.2em] text-primary">A GOOD PLACE TO START</div><h2 className="display-font mt-1 text-[22px] font-extrabold tracking-[-.035em]">Your subjects</h2></div><Link href="/subjects" className="flex items-center gap-1 text-[11px] font-bold text-primary hover:gap-2" data-testid="link-all-subjects">All subjects <ArrowRight size={14} /></Link></div>
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{subjects.map(s => { const Icon = s.icon; return <Link key={s.id} href="/notes" className={`lift-card flex min-h-[119px] items-center gap-4 rounded-2xl border border-border bg-card p-4`} data-testid={`card-home-subject-${s.id}`}><SubjectGlyph subject={s} /><div className="min-w-0 flex-1"><h3 className="truncate text-[13px] font-bold">{s.title}</h3><p className="mt-1 truncate text-[10px] text-muted-foreground">{s.focus}</p><div className="mt-3 text-[10px] text-muted-foreground">{s.notes} notes <span className="px-1">·</span> {s.units} units</div></div><ChevronRight size={16} className="text-muted-foreground" /></Link>; })}</div>
    <div className="mt-9 grid gap-4 md:grid-cols-[1.2fr_.8fr]">
      <section className="rounded-2xl border border-border bg-card p-5 sm:p-6"><div className="mb-4 flex items-center justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[.18em] text-primary">PICK UP THE THREAD</div><h2 className="display-font mt-1 text-[18px] font-extrabold">Recently viewed notes</h2></div><Link href="/notes" className="text-[11px] font-bold text-primary" data-testid="link-recent-notes">View all</Link></div><div className="space-y-1">{recentlyViewedNotes.length ? recentlyViewedNotes.map(n => <Link href={`/notes?search=${encodeURIComponent(n.title)}`} key={n.id} className="flex items-center gap-3 rounded-xl px-2 py-3 hover:bg-muted" data-testid={`row-recent-note-${n.id}`}><span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-primary"><FileText size={16} /></span><span className="min-w-0 flex-1"><span className="block truncate text-[12px] font-semibold">{n.title}</span><span className="mt-1 block text-[10px] text-muted-foreground">{n.subject} <span className="px-1">·</span> {n.unit.split(' · ')[0]}</span></span><span className="text-[10px] text-muted-foreground">Open note</span></Link>) : <p className="py-4 text-[11px] text-muted-foreground">Open a topic and it will be easy to find here next time.</p>}</div></section>
      <section className="rounded-2xl border border-border bg-card p-5 sm:p-6"><div className="mb-3 flex items-center justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[.18em] text-primary">READY FOR REVISION</div><h2 className="display-font mt-1 text-[18px] font-extrabold">Important study materials</h2></div><Link href="/important-questions" className="text-[10px] font-bold text-primary" data-testid="link-important-materials">All questions</Link></div><div className="space-y-1">{questions.slice(0, 3).map(question => <Link key={question.id} href={`/important-questions?search=${encodeURIComponent(question.text)}`} className="block rounded-xl px-2 py-3 hover:bg-muted" data-testid={`row-important-material-${question.id}`}><div className="flex items-center gap-2"><span className="rounded-full bg-secondary px-2 py-1 text-[9px] font-semibold text-primary">{question.marks} marks</span><span className="truncate text-[9px] text-muted-foreground">{question.subject} · {question.unit.split(' · ')[0]}</span></div><p className="mt-2 line-clamp-2 text-[11px] font-semibold leading-5">{question.text}</p></Link>)}</div></section>
    </div>
  </div>;
}
function SubjectGlyph({ subject }: { subject: typeof subjects[number] }) {
  const Icon = subject.icon;
  return <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-[16px] ${subject.color === 'mint' ? 'bg-emerald-100 text-emerald-800' : subject.color === 'sky' ? 'bg-sky-100 text-sky-800' : subject.color === 'peach' ? 'bg-orange-100 text-orange-800' : subject.color === 'yellow' ? 'bg-amber-100 text-amber-900' : subject.color === 'lavender' ? 'bg-violet-100 text-violet-800' : 'bg-rose-100 text-rose-800'} dark:bg-white/10 dark:text-secondary`}><Icon size={21} strokeWidth={1.8} /></span>;
}

function SubjectsPage({ onOpen }: { onOpen: () => void }) {
  const [query, setQuery] = useState(() => new URLSearchParams(window.location.search).get('search') ?? '');
  const filtered = subjects.filter(s => `${s.title} ${s.focus}`.toLowerCase().includes(query.toLowerCase()));
  return <><PageHeading eyebrow="THE FULL PICTURE" title="Your subjects" subtitle="Six courses, one home for each. Open a subject to find your notes, topics and revision material." action={<label className="relative block w-full sm:w-[245px]"><Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Find a subject…" aria-label="Find a subject" data-testid="input-subject-search" className="w-full rounded-xl border border-border bg-card py-2.5 pl-10 pr-3 text-[12px] outline-none focus:border-primary" /></label>} />
    <div className="mb-5 flex items-center gap-2 text-[11px] text-muted-foreground"><span className="rounded-full bg-secondary px-2.5 py-1 font-semibold text-foreground">{filtered.length} subjects</span><span>organized around your semester</span></div>
    {filtered.length ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{filtered.map((s, i) => <button key={s.id} onClick={onOpen} data-testid={`card-subject-${s.id}`} className="lift-card group flex min-h-[205px] flex-col rounded-2xl border border-border bg-card p-5 text-left sm:p-6"><div className="mb-5 flex items-start justify-between"><SubjectGlyph subject={s} /><span className="rounded-full bg-muted px-2.5 py-1 text-[10px] font-semibold text-muted-foreground">{String(i + 1).padStart(2, '0')} / 06</span></div><h2 className="display-font text-[18px] font-extrabold tracking-[-.025em]">{s.title}</h2><p className="mt-1 text-[11px] text-muted-foreground">{s.focus}</p><div className="mt-auto flex items-center justify-between border-t border-border/70 pt-4"><span className="text-[10px] text-muted-foreground">{s.units} units <span className="px-1">·</span> {s.notes} notes</span><span className="flex items-center gap-1 text-[10px] font-bold text-primary group-hover:gap-2">Open notes <ArrowRight size={13} /></span></div></button>)}</div> : <EmptyState icon={Search} title="Nothing in that corner" text="Try a different subject name or topic." />}
    <div className="mt-8 flex flex-col items-start justify-between gap-3 rounded-2xl border border-border bg-[hsl(var(--secondary))] p-5 sm:flex-row sm:items-center"><div><div className="text-[10px] font-bold uppercase tracking-[.16em] text-primary">A NOTE ABOUT YOUR NOTES</div><p className="mt-1 text-[12px] text-muted-foreground">Add your own class notes as your semester takes shape.</p></div><Button variant="outline" testId="button-open-notes" onClick={onOpen}>Go to notes <ArrowRight size={14} /></Button></div>
  </>;
}

function NotesPage({ notes, setNotes, bookmarks, onBookmark, onView }: { notes: StudyNote[]; setNotes: (value: StudyNote[] | ((prev: StudyNote[]) => StudyNote[])) => void; bookmarks: string[]; onBookmark: (id: string) => void; onView: (id: string) => void }) {
  const [query, setQuery] = useState(() => new URLSearchParams(window.location.search).get('search') ?? '');
  const [subject, setSubject] = useState('All subjects');
  const [type, setType] = useState('All types');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [subjectForm, setSubjectForm] = useState('Mathematics');
  const [summary, setSummary] = useState('');
  const filtered = useMemo(() => notes.filter(n => (subject === 'All subjects' || n.subject === subject) && (type === 'All types' || n.type === type) && `${n.title} ${n.subject} ${n.unit} ${n.summary}`.toLowerCase().includes(query.toLowerCase())), [notes, subject, type, query]);
  const submit = (e: FormEvent) => { e.preventDefault(); if (!title.trim()) return; const newNote: StudyNote = { id: `n-${Date.now()}`, subject: subjectForm, unit: 'Unit 1 · New topic', title: title.trim(), summary: summary.trim() || 'A fresh note, ready for your ideas.', updated: 'Just now', type: 'Note' }; setNotes(prev => [newNote, ...prev]); setShowForm(false); setTitle(''); setSummary(''); };
  const remove = (id: string) => { if (window.confirm('Remove this note from your study space?')) setNotes(prev => prev.filter(n => n.id !== id)); };
  return <><PageHeading eyebrow="YOUR KNOWLEDGE, IN ONE PLACE" title="Notes & topics" subtitle="Search across your class notes, then narrow down by subject or material type." action={<Button testId="button-new-note" onClick={() => setShowForm(!showForm)}><Plus size={15} /> New note</Button>} />
    {showForm && <form onSubmit={submit} className="mb-5 grid gap-3 rounded-2xl border border-border bg-card p-4 sm:grid-cols-[1fr_190px] sm:p-5"><div className="grid gap-3 sm:col-span-2 sm:grid-cols-[1fr_190px]"><label className="text-[11px] font-semibold">Note title<input required value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Eigenvalues at a glance" className="mt-1.5 w-full rounded-xl border border-border bg-background px-3 py-2.5 text-[12px] outline-none focus:border-primary" data-testid="input-note-title" /></label><label className="text-[11px] font-semibold">Subject<select value={subjectForm} onChange={e => setSubjectForm(e.target.value)} className="mt-1.5 w-full rounded-xl border border-border bg-background px-3 py-2.5 text-[12px]" data-testid="select-note-subject">{subjects.map(s => <option key={s.id}>{s.title}</option>)}</select></label></div><label className="text-[11px] font-semibold sm:col-span-2">Quick summary<textarea value={summary} onChange={e => setSummary(e.target.value)} rows={2} placeholder="What should future-you remember?" className="mt-1.5 w-full resize-y rounded-xl border border-border bg-background px-3 py-2.5 text-[12px] outline-none focus:border-primary" data-testid="input-note-summary" /></label><div className="flex gap-2 sm:col-span-2"><Button type="submit" testId="button-save-note"><Check size={15} /> Save note</Button><Button variant="outline" testId="button-cancel-note" onClick={() => setShowForm(false)}>Cancel</Button></div></form>}
    <div className="mb-5 flex flex-col gap-3 rounded-2xl border border-border bg-card p-3 sm:flex-row sm:items-center sm:p-4"><label className="relative min-w-0 flex-1"><Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" /><input value={query} onChange={e => setQuery(e.target.value)} aria-label="Search notes" placeholder="Search notes, units, or keywords…" className="w-full rounded-xl bg-muted/70 py-2.5 pl-10 pr-3 text-[12px] outline-none focus:ring-2 focus:ring-primary/20" data-testid="input-notes-search" /></label><select aria-label="Filter by subject" value={subject} onChange={e => setSubject(e.target.value)} className="rounded-xl border border-border bg-background px-3 py-2.5 text-[11px]" data-testid="select-notes-subject"><option>All subjects</option>{subjects.map(s => <option key={s.id}>{s.title}</option>)}</select><select aria-label="Filter by type" value={type} onChange={e => setType(e.target.value)} className="rounded-xl border border-border bg-background px-3 py-2.5 text-[11px]" data-testid="select-notes-type"><option>All types</option><option>Note</option><option>Topic</option></select></div>
    <div className="mb-4 flex items-center justify-between text-[11px] text-muted-foreground"><span>{filtered.length} {filtered.length === 1 ? 'result' : 'results'}</span>{(query || subject !== 'All subjects' || type !== 'All types') && <button onClick={() => { setQuery(''); setSubject('All subjects'); setType('All types'); }} className="flex items-center gap-1 font-semibold text-primary" data-testid="button-clear-note-filters"><RotateCcw size={12} /> Clear filters</button>}</div>
     {filtered.length ? <div className="grid gap-3 lg:grid-cols-2">{filtered.map((n, i) => <article key={n.id} className="rounded-2xl border border-border bg-card p-4 sm:p-5" data-testid={`card-note-${n.id}`}><div className="flex items-start gap-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${i % 2 ? 'bg-[hsl(var(--accent))] text-accent-foreground' : 'bg-secondary text-primary'}`}><FileText size={18} /></span><div className="min-w-0 flex-1"><div className="mb-1 flex flex-wrap items-center gap-2"><span className="text-[9px] font-bold uppercase tracking-[.13em] text-primary">{n.subject}</span><span className="text-[9px] text-muted-foreground">/</span><span className="text-[9px] text-muted-foreground">{n.unit}</span></div><h2 className="display-font text-[16px] font-bold tracking-[-.025em]">{n.title}</h2></div><button aria-label={bookmarks.includes(n.id) ? 'Remove bookmark' : 'Bookmark note'} onClick={() => onBookmark(n.id)} className={`rounded-lg p-2 ${bookmarks.includes(n.id) ? 'text-primary' : 'text-muted-foreground hover:bg-muted'}`} data-testid={`button-bookmark-note-${n.id}`}><Bookmark size={16} fill={bookmarks.includes(n.id) ? 'currentColor' : 'none'} /></button></div><p className="mt-3 text-[11px] leading-5 text-muted-foreground">{n.summary}</p>{expanded === n.id && <div className="mt-3 rounded-xl bg-muted/70 p-3 text-[11px] leading-5"><div className="font-bold text-foreground">Unit outline</div><p className="mt-1 text-muted-foreground">{n.unit} · Key definitions · Worked examples · Check your understanding</p></div>}<div className="mt-4 flex items-center justify-between border-t border-border/70 pt-3"><span className="flex items-center gap-1.5 text-[10px] text-muted-foreground"><Clock3 size={12} /> Updated {n.updated}</span><div className="flex items-center gap-3"><button onClick={() => remove(n.id)} className="text-[10px] font-semibold text-muted-foreground hover:text-destructive" data-testid={`button-delete-note-${n.id}`}>Remove</button><button onClick={() => { const isOpening = expanded !== n.id; setExpanded(isOpening ? n.id : null); if (isOpening) onView(n.id); }} className="flex items-center gap-1 text-[10px] font-bold text-primary" data-testid={`button-expand-note-${n.id}`}>{expanded === n.id ? 'Less' : 'Open topic'} <ChevronDown size={13} className={expanded === n.id ? 'rotate-180' : ''} /></button></div></div></article>)}</div> : <EmptyState icon={NotebookPen} title="No notes on this page" text="Try another search, or make a new note for this subject." action={<Button testId="button-empty-create-note" onClick={() => setShowForm(true)}><Plus size={14} /> Make a note</Button>} />}
  </>;
}

function QuestionsPage({ bookmarks, onBookmark }: { bookmarks: string[]; onBookmark: (id: string) => void }) {
  const [query, setQuery] = useState(() => new URLSearchParams(window.location.search).get('search') ?? '');
  const [subject, setSubject] = useState('All subjects');
  const filtered = questions.filter(q => (subject === 'All subjects' || q.subject === subject) && `${q.text} ${q.subject} ${q.unit}`.toLowerCase().includes(query.toLowerCase()));
  return <><PageHeading eyebrow="PRACTICE WITH PURPOSE" title="Important questions" subtitle="A unit-wise revision set to help you find the shape of an answer before exam day." />
    <div className="mb-5 flex flex-col gap-3 rounded-2xl border border-border bg-card p-3 sm:flex-row"><label className="relative flex-1"><Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" /><input aria-label="Search exam questions" data-testid="input-question-search" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search a question or unit…" className="w-full rounded-xl bg-muted/70 py-2.5 pl-10 pr-3 text-[12px] outline-none" /></label><select value={subject} onChange={e => setSubject(e.target.value)} aria-label="Filter questions by subject" className="rounded-xl border border-border bg-background px-3 py-2.5 text-[11px]" data-testid="select-question-subject"><option>All subjects</option>{subjects.map(s => <option key={s.id}>{s.title}</option>)}</select></div>
    <div className="mb-4 flex items-center justify-between"><div className="text-[11px] text-muted-foreground">{filtered.length} questions across {subject === 'All subjects' ? 'your subjects' : subject}</div><span className="flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-[10px] font-semibold text-primary"><Star size={11} /> Revision set</span></div>
    {filtered.length ? <div className="space-y-3">{filtered.map((q, i) => <article key={q.id} className="grid gap-3 rounded-2xl border border-border bg-card p-4 sm:grid-cols-[42px_1fr_auto] sm:items-start sm:p-5" data-testid={`card-question-${q.id}`}><span className="grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--secondary))] text-[11px] font-bold text-primary">{String(i + 1).padStart(2, '0')}</span><div><div className="mb-2 flex flex-wrap items-center gap-2"><span className="text-[9px] font-bold uppercase tracking-[.15em] text-primary">{q.subject}</span><span className="text-[9px] text-muted-foreground">{q.unit}</span></div><p className="max-w-3xl text-[13px] font-semibold leading-6">{q.text}</p><div className="mt-3 flex flex-wrap gap-2"><span className="rounded-full bg-muted px-2.5 py-1 text-[9px] font-medium text-muted-foreground">{q.kind}</span><span className="rounded-full bg-muted px-2.5 py-1 text-[9px] font-medium text-muted-foreground">{q.marks} marks</span></div></div><button onClick={() => onBookmark(q.id)} aria-label={bookmarks.includes(q.id) ? 'Remove saved question' : 'Save question'} className={`justify-self-end rounded-xl border border-border p-2.5 ${bookmarks.includes(q.id) ? 'bg-secondary text-primary' : 'text-muted-foreground hover:bg-muted'}`} data-testid={`button-bookmark-question-${q.id}`}><Bookmark size={16} fill={bookmarks.includes(q.id) ? 'currentColor' : 'none'} /></button></article>)}</div> : <EmptyState icon={FileQuestion} title="No questions found" text="Try a broader search or choose another subject." />}
    <div className="mt-7 rounded-2xl bg-primary p-5 text-primary-foreground sm:flex sm:items-center sm:justify-between sm:p-6"><div><div className="text-[10px] font-bold uppercase tracking-[.18em] opacity-60">STUDY TIP</div><p className="mt-2 text-[13px] font-semibold">Try answering from memory before you open your notes.</p><p className="mt-1 text-[11px] opacity-65">A little retrieval practice goes a long way.</p></div><ScrollText className="mt-4 opacity-40 sm:mt-0" size={36} /></div>
  </>;
}

function PdfsPage({ pdfs, setPdfs }: { pdfs: SavedPdf[]; setPdfs: (value: SavedPdf[] | ((prev: SavedPdf[]) => SavedPdf[])) => void }) {
  const [selected, setSelected] = useState<string | null>(null);
  const [error, setError] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const addFiles = (files: FileList | null) => {
    if (!files) return;
    const accepted = Array.from(files).filter(f => f.type === 'application/pdf');
    if (accepted.length !== files.length) setError('Only PDF files can be added to your shelf.');
    else setError('');
    const added = accepted.map(file => ({ id: `pdf-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name: file.name, size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`, url: URL.createObjectURL(file), added: 'Just now' }));
    setPdfs(prev => [...added, ...prev]); if (added.length) setSelected(added[0].id);
  };
  const remove = (pdf: SavedPdf) => { URL.revokeObjectURL(pdf.url); setPdfs(prev => prev.filter(p => p.id !== pdf.id)); if (selected === pdf.id) setSelected(null); };
  const current = pdfs.find(p => p.id === selected);
  return <><PageHeading eyebrow="YOUR DIGITAL BOOKSHELF" title="PDF shelf" subtitle="Bring your lecture handouts and reference PDFs into one place. Files stay in this browser session." action={<><input ref={fileInput} type="file" accept="application/pdf,.pdf" multiple hidden onChange={e => addFiles(e.target.files)} data-testid="input-pdf-upload" /><Button testId="button-upload-pdf" onClick={() => fileInput.current?.click()}><Upload size={15} /> Add PDFs</Button></>} />
    <div className="mb-5 flex items-start gap-3 rounded-xl border border-[hsl(var(--primary)/.15)] bg-secondary/55 px-4 py-3 text-[11px] leading-5 text-muted-foreground"><Info size={15} className="mt-0.5 shrink-0 text-primary" /><p>PDFs are kept as temporary browser object URLs. Refreshing the page clears this session shelf; your files are not uploaded anywhere.</p></div>
    {error && <div role="alert" className="mb-4 flex items-center justify-between rounded-xl bg-destructive/10 px-4 py-3 text-[11px] text-destructive" data-testid="status-pdf-error">{error}<button onClick={() => setError('')} aria-label="Dismiss upload message"><X size={14} /></button></div>}
    {!pdfs.length ? <div className="rounded-2xl border border-dashed border-border bg-card/60 p-8 sm:p-12"><div className="mx-auto flex max-w-md flex-col items-center text-center"><span className="grid h-16 w-16 place-items-center rounded-[22px] bg-secondary text-primary"><FileText size={28} /></span><h2 className="display-font mt-5 text-[20px] font-extrabold">A shelf with room to grow</h2><p className="mt-2 text-[12px] leading-5 text-muted-foreground">Add class handouts, past papers or reference material. Your PDFs preview right here in the browser.</p><Button testId="button-empty-upload-pdf" onClick={() => fileInput.current?.click()}><Upload size={14} /> Choose a PDF</Button><div className="mt-3 text-[10px] text-muted-foreground">PDF files only · never leaves your device</div></div></div> : <div className="grid gap-4 lg:grid-cols-[310px_1fr]"><section className="rounded-2xl border border-border bg-card p-4"><div className="mb-3 flex items-center justify-between"><h2 className="text-[12px] font-bold">Your shelf <span className="ml-1 font-normal text-muted-foreground">{pdfs.length}</span></h2><button onClick={() => fileInput.current?.click()} className="rounded-lg p-2 text-primary hover:bg-secondary" aria-label="Add another PDF" data-testid="button-add-another-pdf"><Plus size={16} /></button></div><div className="space-y-2">{pdfs.map(p => <div key={p.id} className={`rounded-xl border p-3 ${selected === p.id ? 'border-primary/35 bg-secondary/55' : 'border-border'}`} data-testid={`row-pdf-${p.id}`}><button onClick={() => setSelected(p.id)} className="flex w-full items-center gap-3 text-left" data-testid={`button-select-pdf-${p.id}`}><span className="grid h-9 w-9 place-items-center rounded-lg bg-accent text-accent-foreground"><FileText size={16} /></span><span className="min-w-0 flex-1"><span className="block truncate text-[11px] font-semibold">{p.name}</span><span className="mt-1 block text-[9px] text-muted-foreground">{p.size} · {p.added}</span></span></button><button onClick={() => remove(p)} className="ml-[48px] mt-2 text-[9px] font-semibold text-muted-foreground hover:text-destructive" data-testid={`button-remove-pdf-${p.id}`}>Remove</button></div>)}</div></section><section className="min-h-[420px] overflow-hidden rounded-2xl border border-border bg-card">{current ? <><div className="flex items-center justify-between border-b border-border px-4 py-3"><div className="flex min-w-0 items-center gap-2"><FileText size={15} className="shrink-0 text-primary" /><span className="truncate text-[11px] font-semibold">{current.name}</span></div><a href={current.url} target="_blank" rel="noreferrer" className="ml-3 flex shrink-0 items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-[10px] font-semibold hover:bg-muted" data-testid="link-pdf-new-tab"><ExternalLink size={12} /> New tab</a></div><iframe title={`PDF preview: ${current.name}`} src={current.url} className="h-[600px] w-full bg-muted" data-testid="frame-pdf-preview" /></> : <EmptyState icon={FileText} title="Choose a PDF to read" text="Pick a file on the left to open its in-browser preview." />}</section></div>}
  </>;
}

function AiPage() {
  const [messages, setMessages] = useState<ChatLine[]>([{ role: 'assistant', text: 'Hi Rathesh, what are you working through today? Tell me the topic and where it starts to feel confusing. I’ll help you find a clear first step.' }]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }); }, [messages, busy]);
  const send = (e: FormEvent) => {
    e.preventDefault(); const question = input.trim(); if (!question || busy) return;
    setMessages(prev => [...prev, { role: 'user', text: question }]); setInput(''); setBusy(true);
    window.setTimeout(() => { setMessages(prev => [...prev, { role: 'assistant', text: demoAnswer(question) }]); setBusy(false); }, 620);
  };
  const prompts = ['Explain limits in simple steps', 'How do pointers work in C?', 'Help me revise work and energy'];
  return <><PageHeading eyebrow="A PATIENT STUDY PARTNER" title="Ask StudyMate" subtitle="A place to ask the small question that unlocks the bigger idea." />
    <div className="grid gap-5 lg:grid-cols-[1fr_270px]">
      <section className="flex min-h-[570px] flex-col overflow-hidden rounded-2xl border border-border bg-card soft-shadow" aria-label="StudyMate chat">
        <div className="flex items-center justify-between border-b border-border px-4 py-3 sm:px-5"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-primary"><Sparkles size={17} /></span><div><div className="text-[12px] font-bold">StudyMate guide</div><div className="mt-0.5 flex items-center gap-1.5 text-[9px] text-muted-foreground"><span className="h-1.5 w-1.5 rounded-full bg-amber-500" /> Demo mode</div></div></div><button onClick={() => setMessages([{ role: 'assistant', text: 'Fresh page, clear mind. What would you like to understand?' }])} className="flex items-center gap-1.5 rounded-lg px-2.5 py-2 text-[10px] font-semibold text-muted-foreground hover:bg-muted" data-testid="button-clear-chat"><RotateCcw size={13} /> New chat</button></div>
        <div ref={scrollRef} className="flex flex-1 flex-col gap-4 overflow-y-auto p-4 sm:p-6" data-testid="content-chat-messages">{messages.map((m, i) => <div key={`${i}-${m.role}`} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`} data-testid={`message-${m.role}-${i}`}><div className={`max-w-[88%] whitespace-pre-line rounded-2xl px-4 py-3 text-[12px] leading-6 ${m.role === 'user' ? 'rounded-br-md bg-primary text-primary-foreground' : 'rounded-bl-md bg-muted/80 text-foreground'}`}>{m.role === 'assistant' && <div className="mb-1.5 flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-[.12em] text-primary"><Sparkles size={11} /> StudyMate · demo response</div>}{m.text}</div></div>)}{busy && <div className="flex items-center gap-2 self-start rounded-2xl bg-muted px-4 py-3 text-[11px] text-muted-foreground" role="status" data-testid="status-chat-thinking"><span className="flex gap-1"><i className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" /><i className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary [animation-delay:150ms]" /><i className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary [animation-delay:300ms]" /></span>Putting a simple explanation together…</div>}</div>
        {!messages.some(m => m.role === 'user') && <div className="px-4 pb-3 sm:px-6"><div className="mb-2 text-[9px] font-bold uppercase tracking-[.14em] text-muted-foreground">Try asking</div><div className="flex flex-wrap gap-2">{prompts.map((p, i) => <button key={p} onClick={() => setInput(p)} className="rounded-full border border-border bg-background px-3 py-2 text-left text-[10px] text-muted-foreground hover:border-primary/40 hover:text-foreground" data-testid={`button-chat-prompt-${i}`}>{p}</button>)}</div></div>}
        <form onSubmit={send} className="border-t border-border p-3 sm:p-4"><label className="sr-only" htmlFor="chat-message">Your question</label><div className="flex items-end gap-2 rounded-xl border border-border bg-background p-2"><textarea id="chat-message" rows={1} value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); e.currentTarget.form?.requestSubmit(); } }} placeholder="Ask about a concept, formula, or topic…" className="max-h-28 min-h-[38px] flex-1 resize-y bg-transparent px-2 py-2 text-[12px] outline-none placeholder:text-muted-foreground/75" data-testid="input-chat-message" /><button type="submit" disabled={!input.trim() || busy} aria-label="Send question" className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground disabled:opacity-40" data-testid="button-send-question"><Send size={15} /></button></div><div className="mt-2 text-center text-[9px] text-muted-foreground">Replies are demo responses. No live AI service is connected.</div></form>
      </section>
      <aside className="space-y-4"><div className="rounded-2xl border border-border bg-card p-5"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--accent))] text-accent-foreground"><CircleHelp size={19} /></div><h2 className="display-font mt-4 text-[16px] font-extrabold">How to get a helpful answer</h2><ol className="mt-3 space-y-3 text-[11px] leading-5 text-muted-foreground"><li className="flex gap-2"><span className="font-bold text-primary">01</span> Name the subject or unit.</li><li className="flex gap-2"><span className="font-bold text-primary">02</span> Share what you already tried.</li><li className="flex gap-2"><span className="font-bold text-primary">03</span> Ask for one step at a time.</li></ol></div><div className="rounded-2xl bg-secondary p-5"><div className="text-[10px] font-bold uppercase tracking-[.15em] text-primary">A CLEAR NOTE</div><p className="serif-font mt-3 text-[21px] leading-snug">Understanding grows when you ask.</p><p className="mt-2 text-[10px] leading-5 text-muted-foreground">Use replies as a starting point, then check important details against your class material.</p></div><div className="rounded-xl border border-border px-4 py-3 text-[10px] leading-5 text-muted-foreground"><Info size={13} className="mr-1 inline text-primary" />Demo answers only. The chat adapter is ready for a future backend connection.</div></aside>
    </div>
  </>;
}

function BookmarksPage({ notes, bookmarks, onBookmark }: { notes: StudyNote[]; bookmarks: string[]; onBookmark: (id: string) => void }) {
  const savedNotes = notes.filter(n => bookmarks.includes(n.id));
  const savedQuestions = questions.filter(q => bookmarks.includes(q.id));
  return <><PageHeading eyebrow="KEEP THE GOOD BITS CLOSE" title="Bookmarks" subtitle="A small collection of notes and questions you want to find again." />
    <div className="mb-5 flex flex-wrap gap-2"><span className="rounded-full bg-secondary px-3 py-1.5 text-[10px] font-semibold">{savedNotes.length} notes</span><span className="rounded-full bg-accent px-3 py-1.5 text-[10px] font-semibold text-accent-foreground">{savedQuestions.length} questions</span></div>
    {!savedNotes.length && !savedQuestions.length ? <EmptyState icon={Bookmark} title="Your shortlist starts here" text="Bookmark a note or an exam question and it will be waiting right here." /> : <div className="grid gap-7 xl:grid-cols-2">
      <section><div className="mb-3 flex items-center gap-2"><NotebookPen size={15} className="text-primary" /><h2 className="display-font text-[16px] font-extrabold">Saved notes</h2></div>{savedNotes.length ? <div className="space-y-3">{savedNotes.map(n => <article key={n.id} className="rounded-2xl border border-border bg-card p-4" data-testid={`card-bookmarked-note-${n.id}`}><div className="flex items-start justify-between gap-3"><div><div className="text-[9px] font-bold uppercase tracking-[.12em] text-primary">{n.subject} <span className="px-1 text-muted-foreground">/</span> {n.unit}</div><h3 className="display-font mt-1.5 text-[15px] font-bold">{n.title}</h3><p className="mt-2 text-[11px] leading-5 text-muted-foreground">{n.summary}</p></div><button onClick={() => onBookmark(n.id)} aria-label="Remove note bookmark" className="rounded-lg p-2 text-primary hover:bg-secondary" data-testid={`button-unsave-note-${n.id}`}><BookmarkCheck size={17} /></button></div></article>)}</div> : <div className="rounded-2xl border border-dashed border-border p-6 text-center text-[11px] text-muted-foreground">No saved notes yet. Save one from your notes page.</div>}</section>
      <section><div className="mb-3 flex items-center gap-2"><FileQuestion size={15} className="text-primary" /><h2 className="display-font text-[16px] font-extrabold">Saved questions</h2></div>{savedQuestions.length ? <div className="space-y-3">{savedQuestions.map(q => <article key={q.id} className="rounded-2xl border border-border bg-card p-4" data-testid={`card-bookmarked-question-${q.id}`}><div className="flex justify-between gap-3"><div><div className="text-[9px] font-bold uppercase tracking-[.12em] text-primary">{q.subject} <span className="px-1 text-muted-foreground">/</span> {q.unit}</div><p className="mt-2 text-[12px] font-semibold leading-5">{q.text}</p><span className="mt-2 inline-block rounded-full bg-muted px-2 py-1 text-[9px] text-muted-foreground">{q.marks} marks · {q.kind}</span></div><button onClick={() => onBookmark(q.id)} aria-label="Remove question bookmark" className="rounded-lg p-2 text-primary hover:bg-secondary" data-testid={`button-unsave-question-${q.id}`}><BookmarkCheck size={17} /></button></div></article>)}</div> : <div className="rounded-2xl border border-dashed border-border p-6 text-center text-[11px] text-muted-foreground">No saved questions yet. Keep an important one nearby.</div>}</section>
    </div>}
  </>;
}

function ProfilePage({ profile, setProfile, activity, onClearActivity, dark, setDark }: { profile: { name: string; course: string; year: string; email: string; dailyGoal: string }; setProfile: (v: typeof profile) => void; activity: string[]; onClearActivity: () => void; dark: boolean; setDark: (v: boolean) => void }) {
  const [draft, setDraft] = useState(profile);
  const [saved, setSaved] = useState(false);
  useEffect(() => { setDraft(profile); }, [profile]);
  const update = (key: keyof typeof profile, value: string) => setDraft(prev => ({ ...prev, [key]: value }));
  const submit = (e: FormEvent) => { e.preventDefault(); setProfile(draft); setSaved(true); window.setTimeout(() => setSaved(false), 2400); };
  return <><PageHeading eyebrow="MAKE IT YOUR OWN" title="Your profile" subtitle="A few details about your study life, plus the small preferences that make this space yours." />
    <div className="grid gap-5 lg:grid-cols-[1fr_330px]"><form onSubmit={submit} className="rounded-2xl border border-border bg-card p-5 sm:p-7"><div className="mb-6 flex items-center gap-4 border-b border-border pb-5"><div className="grid h-16 w-16 place-items-center rounded-[22px] bg-primary text-[20px] font-bold text-primary-foreground">RB</div><div><h2 className="display-font text-[19px] font-extrabold">{profile.name}</h2><p className="mt-1 text-[11px] text-muted-foreground">Your personal StudyMate profile</p></div></div><div className="grid gap-4 sm:grid-cols-2"><ProfileField label="Name" value={draft.name} onChange={v => update('name', v)} testId="input-profile-name" /><ProfileField label="Course / focus" value={draft.course} onChange={v => update('course', v)} testId="input-profile-course" /><label className="text-[11px] font-semibold">Year of study<select value={draft.year} onChange={e => update('year', e.target.value)} className="mt-1.5 w-full rounded-xl border border-border bg-background px-3 py-2.5 text-[12px]" data-testid="select-profile-year">{['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Other'].map(y => <option key={y}>{y}</option>)}</select></label><ProfileField label="Email (optional)" value={draft.email} onChange={v => update('email', v)} testId="input-profile-email" /><label className="text-[11px] font-semibold sm:col-span-2">Daily study intention<select value={draft.dailyGoal} onChange={e => update('dailyGoal', e.target.value)} className="mt-1.5 w-full rounded-xl border border-border bg-background px-3 py-2.5 text-[12px]" data-testid="select-study-goal">{['20 minutes', '30 minutes', '45 minutes', '1 hour', 'A little every day'].map(g => <option key={g}>{g}</option>)}</select><span className="mt-1 block text-[9px] font-normal text-muted-foreground">A gentle reminder to make a little space for learning.</span></label></div><div className="mt-6 flex flex-wrap items-center gap-3"><Button type="submit" testId="button-save-profile"><Check size={14} /> Save profile</Button>{saved && <span role="status" className="text-[11px] font-semibold text-primary" data-testid="status-profile-saved">Profile saved in this browser.</span>}</div></form>
      <aside className="space-y-4"><section className="rounded-2xl border border-border bg-card p-5"><div className="flex items-center gap-2"><Settings2 size={16} className="text-primary" /><h2 className="display-font text-[15px] font-extrabold">Preferences</h2></div><div className="mt-4 flex items-center justify-between border-t border-border pt-4"><div><div className="text-[11px] font-semibold">Appearance</div><div className="mt-1 text-[10px] text-muted-foreground">{dark ? 'Evening reading' : 'Daylight study'}</div></div><button type="button" onClick={() => setDark(!dark)} aria-label="Toggle dark theme" className="flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-[10px] font-semibold" data-testid="button-profile-theme">{dark ? <Sun size={14} /> : <Moon size={14} />}{dark ? 'Light' : 'Dark'}</button></div></section>
      <section className="rounded-2xl border border-border bg-card p-5"><div className="mb-4 flex items-center gap-2"><Activity size={16} className="text-primary" /><h2 className="display-font text-[15px] font-extrabold">Recent activity</h2></div>{activity.length ? <div className="space-y-3">{activity.slice(0, 5).map((item, i) => <div key={`${item}-${i}`} className="flex gap-3" data-testid={`text-activity-${i}`}><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><p className="text-[10px] leading-5 text-muted-foreground">{item}</p></div>)}</div> : <p className="text-[11px] text-muted-foreground">Your study activity will show up here.</p>}<button onClick={onClearActivity} className="mt-4 text-[10px] font-semibold text-muted-foreground underline underline-offset-4 hover:text-foreground" data-testid="button-clear-activity">Clear activity</button></section><div className="rounded-2xl bg-secondary p-5"><div className="text-[9px] font-bold uppercase tracking-[.17em] text-primary">YOUR INTENTION</div><p className="serif-font mt-2 text-[22px] leading-tight">Make room to understand.</p><p className="mt-2 text-[10px] leading-5 text-muted-foreground">No streaks, no pressure. Just a space that meets you where you are.</p></div></aside>
    </div>
  </>;
}
function ProfileField({ label, value, onChange, testId }: { label: string; value: string; onChange: (value: string) => void; testId: string }) {
  return <label className="text-[11px] font-semibold">{label}<input value={value} onChange={e => onChange(e.target.value)} className="mt-1.5 w-full rounded-xl border border-border bg-background px-3 py-2.5 text-[12px] outline-none focus:border-primary" data-testid={testId} /></label>;
}

function AboutPage() {
  const [showDetails, setShowDetails] = useState(false);
  return <><PageHeading eyebrow="A SMALL SPACE FOR BIG IDEAS" title="About StudyMate" subtitle="Built to make the everyday work of learning feel a little more together." />
    <section className="relative overflow-hidden rounded-[28px] bg-primary px-6 py-9 text-primary-foreground sm:px-10 sm:py-12"><div className="paper-grid absolute inset-0 opacity-40" /><div className="absolute -right-8 -top-16 h-64 w-64 rounded-full border border-white/10" /><div className="relative max-w-3xl"><div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 px-3 py-1.5 text-[9px] font-bold uppercase tracking-[.18em]"><GraduationCap size={13} /> Built around student life</div><h2 className="display-font max-w-2xl text-[27px] font-extrabold leading-tight tracking-[-.04em] sm:text-[38px]">Scattered class material.<br /><span className="serif-font font-medium italic">One calmer place to land.</span></h2><p className="mt-5 max-w-2xl text-[13px] leading-7 text-primary-foreground/75">StudyMate is a student-focused platform designed to organize college notes, study materials and academic resources in one simple place.</p></div></section>
    <div className="mt-6 grid gap-4 md:grid-cols-[1.15fr_.85fr]"><section className="rounded-2xl border border-border bg-card p-6 sm:p-8"><div className="text-[10px] font-bold uppercase tracking-[.18em] text-primary">THE IDEA</div><h3 className="serif-font mt-3 text-[28px] leading-tight">Clarity is a study tool.</h3><p className="mt-3 max-w-xl text-[12px] leading-6 text-muted-foreground">Notes end up in different notebooks. Questions sit in old messages. PDFs go missing just when you need them. StudyMate brings those pieces into a personal workspace that is easy to return to.</p><div className="mt-6 grid gap-3 sm:grid-cols-3">{[{ icon: NotebookPen, label: 'Collect', detail: 'Notes & unit topics' }, { icon: FileQuestion, label: 'Practice', detail: 'Important questions' }, { icon: MessageCircle, label: 'Unstick', detail: 'Ask for clarity' }].map(({ icon: Icon, label, detail }) => <div key={label} className="rounded-xl bg-muted/65 p-4"><Icon size={17} className="text-primary" /><div className="mt-3 text-[12px] font-bold">{label}</div><div className="mt-1 text-[10px] text-muted-foreground">{detail}</div></div>)}</div></section><section className="flex flex-col justify-between rounded-2xl bg-[hsl(var(--secondary))] p-6 sm:p-8"><div><div className="text-[10px] font-bold uppercase tracking-[.18em] text-primary">THE PERSON BEHIND IT</div><div className="mt-4 flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-card text-[14px] font-bold text-primary">RB</span><div><h3 className="display-font text-[17px] font-extrabold">Rathesh B</h3><p className="mt-0.5 text-[10px] text-muted-foreground">Founder & student</p></div></div><p className="mt-5 text-[12px] leading-6 text-muted-foreground">A student-built study space, shaped by the simple wish to make learning materials easier to find and easier to use.</p></div><button onClick={() => setShowDetails(!showDetails)} className="mt-5 flex items-center justify-between border-t border-primary/10 pt-4 text-left text-[11px] font-semibold text-primary" data-testid="button-about-details"><span>{showDetails ? 'A little less' : 'What is StudyMate built for?'}</span><ChevronDown size={15} className={showDetails ? 'rotate-180' : ''} /></button>{showDetails && <p className="mt-3 text-[11px] leading-5 text-muted-foreground">This first version keeps study data in your browser. It is designed to grow with thoughtful integrations later—without losing its focus on approachable, student-friendly learning.</p>}</section></div>
    <div className="mt-6 flex flex-col items-start justify-between gap-4 rounded-2xl border border-border bg-card px-5 py-5 sm:flex-row sm:items-center sm:px-7"><div><div className="serif-font text-[23px]">Learn smarter. Study better.</div><p className="mt-1 text-[11px] text-muted-foreground">Your next good study session can start right here.</p></div><Link href="/subjects" className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-[11px] font-semibold text-primary-foreground" data-testid="link-about-subjects">Explore your subjects <ArrowRight size={14} /></Link></div>
  </>;
}

export default App;
